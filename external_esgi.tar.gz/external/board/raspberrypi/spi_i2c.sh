#!/bin/sh

echo "dtparam=i2c_arm=on,spi=on" >>  ${BINARIES_DIR}/rpi-firmware/config.txt
